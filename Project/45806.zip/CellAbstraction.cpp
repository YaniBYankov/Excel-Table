#include "CellAbstraction.hpp"

CellAbstraction::~CellAbstraction(){}
